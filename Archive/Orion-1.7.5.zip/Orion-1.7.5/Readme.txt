OVERVIEW
===================================================================================================================
This pack provides the eponymous engine from Project Orion, as well as the parts to build Project Orion vessel designs.


INSTALLATION
===================================================================================================================
Delete the previous version of Orion (if any) and place the GameData/Orion, Gamedata/CommunityResourcePack,  If Module Manager is not already intalled, place the ModuleManager.dll into GameData.

LICENSE
===================================================================================================================
This work is licensed under a MIT license.

ModuleManager - made by Sarbian & Ialdabaoth - http://forum.kerbalspaceprogram.com/threads/55219-Module-Manager-1-5-6-%28Jan-6%29


Community Resource Pack, more details at http://forum.kerbalspaceprogram.com/threads/91998

