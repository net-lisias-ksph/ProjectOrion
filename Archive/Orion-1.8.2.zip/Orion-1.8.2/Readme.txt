OVERVIEW
===================================================================================================================
This pack provides the eponymous engine from Project Orion, as well as the parts to build Project Orion vessel designs.


INSTALLATION
===================================================================================================================
Version 1.8.2 changed the engine module name. For best results, retire or recover all Orion-equipped vessels prior to installation.
Delete the previous version of Orion (if any) and place the GameData/Orion folder into your Kerbal Space Program/gamedata Directory. If CommunityResourcePack and/or Module Manager are not installed, place the Gamedata/CommunityResourcePack and/or Modulemanager.dll into your Kerbal Space Program/GameData directory.
(Optional) Place the Ships folder into your Kerbal Space Program directory and allow the folder merge. Note: two of the example craft require the Making History DLC.

LICENSE
===================================================================================================================
This work is licensed under a MIT license.

ModuleManager - made by Sarbian & Ialdabaoth - http://forum.kerbalspaceprogram.com/threads/55219-Module-Manager-1-5-6-%28Jan-6%29


Community Resource Pack, more details at http://forum.kerbalspaceprogram.com/threads/91998

